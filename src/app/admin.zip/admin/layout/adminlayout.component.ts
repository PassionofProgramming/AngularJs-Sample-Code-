import { Component, OnInit } from '@angular/core';

@Component({
    selector: 'admin-layout',
    templateUrl: './adminlayout.component.html',
    styleUrls: ['./adminlayout.component.scss']
})
export class LayoutComponent implements OnInit {
    constructor() {}

    ngOnInit() {}
}
